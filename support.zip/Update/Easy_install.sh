#!/bin/sh
echo "------------------------------------------"
 apt update
 apt remove java
 apt install java
for i in `cat remove_pkgs.txt`; do   apt-get remove -y -q $i; done
echo "
#!/bin/bash
if [ -z \$1 ]; then
 echo -e \"at least 1 argument required!\n\" >> /dev/stderr
 exit 1
fi
COMMAND=\$1
shift #shift first arg
for ARG in \"\$@\"
do
 if [ -z \"\$ARGS\" ]; then
  ARGS=\"\$ARG\"
 else
  ARGS=\"\$ARGS $ARG\"
 fi
done
ARGS=\'\$ARGS\'
eval pkexec env DISPLAY=\$DISPLAY XAUTHORITY=\$XAUTHORITY \$COMMAND \$ARGS
exit 0
" > /usr/bin/xsudo

chmod +x /usr/bin/xsudo
mkdir -p /usr/local/share/file-manager/actions/
cat <<EOF > /usr/local/share/file-manager/actions/root.desktop
[Desktop Entry]
Type=Action
Tooltip=Open Folder As Root
Name=Open Folder As Root
Profiles=profile-zero;
Icon=gtk-dialog-authentication

[X-Action-Profile profile-zero]
MimeTypes=inode/directory;
Exec=/usr/bin/xsudo /usr/bin/pcmanfm %u
Name=Default profile

EOF
#sudo ./mk_xsudo.sh
 apt autoremove
 apt autoremove --purge
 apt update
 apt -y upgrade
 apt --fix-broken install
# Count the number of packages installed on your system

pkcnt=` dpkg-query -f '${binary:Package}\n' -W | wc -l`
echo "There are $pkcnt installed packages"
# List all packages installed

if [ -z "$1" ]
then
    echo "---------------------------"
    echo "No arguments received"
    echo "---------------------------"
echo "---------------Installing Listed Packages-----------------"

# Create list of local packages
 touch packages_list.txt
 ls `pwd`/*.deb >/tmp/tmp.txt
 dpkg-query -f '${binary:Package}\n' -W > /tmp/tmp2.txt
 grep -w -v -f /tmp/tmp2.txt /tmp/tmp.txt >/tmp/local_pkgs.txt
 dpkg-query -f '${binary:Package}\n' -W > /tmp/tmp2.txt
 grep -w -v -f /tmp/tmp2.txt packages_list.txt > /tmp/tmp3.txt
 grep -w -v -f remove_list.txt /tmp/tmp3.txt > /tmp/tmp1.txt
 grep -w -v -f ignore_list.txt /tmp/tmp1.txt > /tmp/To_install.txt
 xargs -a /tmp/local_pkgs.txt apt-get install -y
 apt -y upgrade
 apt --fix-broken install
echo "---------------Ready to install packages ------------"
for i in `cat /tmp/To_install.txt`; do   apt  install -y $i;done #-m --ignore-missing
# rm /tmp/To_install.txtsudo grep -w -v -f ignore_list.txt /tmp/tmp.txt > /tmp/tmp2.txt
echo "--------------------- Installing Xournal++----------------------"
 add-apt-repository -y ppa:andreasbutti/xournalpp-master
 apt update
 apt -y  install xournalpp

# install anydesk
wget -qO - https://keys.anydesk.com/repos/DEB-GPG-KEY |  apt-key add -
echo "deb http://deb.anydesk.com/ all main" |  tee /etc/apt/sources.list.d/anydesk-stable.list
 apt update
 apt -y install anydesk
#install all packages from list
 apt-get update
 apt-get install -f
for i in ~/.local/share/applications/*.desktop; do which $(grep -Poh '(?<=Exec=).*?( |$)' $i) > /dev/null || trash $i; done

elif [ "$1"=="backup" ]
then
    echo "----------------------------------------------------------"
    echo "backup demanded"
     ls `pwd`/*.deb >/tmp/local_pkgs.txt
     dpkg-query -f '${binary:Package}\n' -W > /tmp/tmp.txt
     grep -w -v -f ignore_list.txt /tmp/tmp.txt > /tmp/tmp2.txt
     grep -w -v -f /tmp/local_pkgs.txt /tmp/tmp2.txt > packages_list.txt
     rm /tmp/tmp.txt /tmp/tmp2.txt
    echo "---------------------------------------------------------"
else [ "$1"=="restore" ]
 apt install --reinstall lubuntu-desktop
 apt-get update --fix-missing
fi



